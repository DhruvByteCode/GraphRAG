# CLI Reference

This page documents the command-line interface of the graphrag library.

::: mkdocs-typer
    :module: graphrag.cli.main
    :prog_name: graphrag
    :command: app
    :depth: 0

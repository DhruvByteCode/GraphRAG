# Copyright (c) 2024 Microsoft Corporation.
# Licensed under the MIT License

"""The GraphRAG package."""

from graphrag.cli.main import app

app(prog_name="graphrag")
